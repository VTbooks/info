################ 辅助 ，补充 A3Detail的json数据 ### 补充json数据中 的 下载链接数据
### 已使用完毕 2024=05=26 16.49

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random



### 这个函数 用于 补充json数据中 的 下载链接数据 ，修改图片链接的数据
def hepLoadJson():
    path = '../Srcs/comicdetail.json'
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    ### 补充json数据中 的 下载链接数据 ，修改图片链接的数据
    for key in jsContent:
        temkey = key                    # 这是 json 的 key , 也是作品的id

        temZhi = jsContent[key]         # 这是 得到一条数据

        BSuoPic = temZhi['BSuoPic']        # 获得 详细页面 的 缩略图地址 并修改 数据
        temZhi['BSuoPic'] = 'https:' + BSuoPic

        # ABiaoTi = temZhi['ABiaoTi']        # 获得 详细页面 的 标题
        # CFenLei = temZhi['CFenLei']        # 获得 详细页面 的 大分类
        # DPgNum = temZhi['DPgNum']        # 获得 详细页面 的 页数
        # ETag = temZhi['ETag']        # 获得 详细页面 的 分类标签
        # FDstr = temZhi['FDstr']        # 获得 详细页面 的 简介

        temZhi['GDlowlink'] = 'https://www.wnacg.com/download-index-aid-' + temkey + '.html'        # 直接新补充一个数据

    # 4 写入 文件
    with open(path, 'w') as f:
        json.dump(jsContent, f, ensure_ascii=False)       # 保持字符集编码


    return




### 从指定页 起点 开始
### 单行本 单个具体漫画页 数据获取
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")
    hepLoadJson()

