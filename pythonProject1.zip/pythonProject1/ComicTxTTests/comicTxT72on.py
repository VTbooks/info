# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


### 基础设置 ###############################################################


# 创建options对象
options = Options()

# 打开开发者工具，即打开F12
# options.add_argument("--auto-open-devtools-for-tabs")

# 设置浏览器窗口大小
options.add_argument("--window-size=1920,1080")

# 设置页面加载策略
prefs = {"profile.managed_default_content_settings.images": 2}
options.add_experimental_option("prefs", prefs)

# 创建Chrome浏览器实例
driver = webdriver.Chrome(options=options)

# 最大化浏览器窗口
driver.maximize_window()



### 跳至 单行本专页 ###############################################################

# 打开谷歌网页
driver.get('https://www.72on.com')

# 等待页面加载完成
driver.implicitly_wait(2000)

# 等待页面中的按钮出现
wait = WebDriverWait(driver, 2000)
button = wait.until(EC.presence_of_element_located((By.XPATH,'/html/body/header/div/nav/ul/li[2]/a')))


# 执行JavaScript代码，滚动到页面底部
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

# 等待1.5秒
sleep(1.5)

# 点击指定元素(按钮)
button.click()

sleep(6)


# 刷新当前页面
driver.refresh()


sleep(6)


# 关闭浏览器实例
driver.quit()