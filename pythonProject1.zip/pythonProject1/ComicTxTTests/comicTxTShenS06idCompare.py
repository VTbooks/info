### 实验代码        ### json 数据对比
### 对比 两个json 的 id 是否一致 ，保证数据对上
### 已使用完毕 2024=05=26 22.17

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random



### 这个函数 用于 补充json数据中 的 下载链接数据 ，修改图片链接的数据
def hepLoadJson():
    path = 'C:\\Users\\Tbs\\PycharmProjects\\pyth_ShenS\\Srcs\\ZLZaZhi\\ZZcomicdetail.json'
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsSave = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。
    jsSaveIdArr = []
    ### 获得 jsSave里的 id key
    for key in jsSave:
        temkey = key                    # 这是 json 的 key , 也是作品的id
        temkey = int(temkey)
        jsSaveIdArr.append(temkey)

    print('jsdetailIdArr : ' , len(jsSaveIdArr))      # jsSaveIdArr 数组长度


    path = 'C:\\Users\\Tbs\\PycharmProjects\\pyth_ShenS\\Srcs\\ZLZaZhi\\ZZcomicdownlink.json'
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsDetail = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。
    jsDetailIdArr = []
    ### 获得 jsSave里的 id key
    for key in jsDetail:
        temkey = key                    # 这是 json 的 key , 也是作品的id
        temkey = int(temkey)
        jsDetailIdArr.append(temkey)

    print('jsdownlinkArr : ' , len(jsDetailIdArr))      # jsSaveIdArr 数组长度


    # id 相减 为零 测试 ，结果为零 说明 id是一一对应的
    for i in range(len(jsSaveIdArr)):
        temsum = jsSaveIdArr[i] - jsDetailIdArr[i]
        print('temsum : ' , temsum)
        print('\n')

    return




### 从指定页 起点 开始
### 单行本 单个具体漫画页 数据获取
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")
    hepLoadJson()


