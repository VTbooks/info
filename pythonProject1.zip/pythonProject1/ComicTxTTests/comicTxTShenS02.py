### 实验代码

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json


### 基础设置 ###############################################################


# 创建options对象
options = Options()

# 设置浏览器窗口大小
options.add_argument("--window-size=1920,1080")

# 设置页面加载策略
prefs = {"profile.managed_default_content_settings.images": 2}
options.add_experimental_option("prefs", prefs)

# 创建Chrome浏览器实例
driver = webdriver.Chrome(options=options)

# 最大化浏览器窗口
driver.maximize_window()

sleep(4)


### 跳至 单行本专页 ###############################################################

# 打开comic网页
driver.get('https://www.wnacg.com')

# 等待页面加载完成
driver.implicitly_wait(2000)

# 等待页面中的指定元素(按钮)出现
wait = WebDriverWait(driver, 2000)
button = wait.until(EC.presence_of_element_located((By.XPATH,'/html/body/div[7]/div[3]/a')))

# 执行JavaScript代码，滚动到页面底部
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

# 等待1.5秒
sleep(1.5)

# 点击指定元素(按钮)
button.click()
# 等待页面加载完成
driver.implicitly_wait(2000)

sleep(4)




### 翻专页 ，目标获得专页内的数据 ###############################################################

# 设定 指定页码
specilNum = 1

# 1）获得页面源代码
htmlsrc = driver.page_source
# print(htmlsrc)

# 2）解析页面源代码 ，并获取指定数据 ，并保存
soup = BeautifulSoup(htmlsrc, 'lxml')
soup.prettify()   # 格式化


# 得到指定 标签 的 html片段
htmlpart = soup.select('#bodywrap > div.grid > div.gallary_wrap > ul')
#print(htmlpart)

# 创建json数据
TotaljsData = {}

# 遍歷htmlpart下的所有li標籤
Li_item = htmlpart

for tem in htmlpart:
    Li_item = tem


ouji = 0    # 用于取模 。下面这个标签for循环很奇怪 ，一个标签会循环2次

for xLi in Li_item:
    print("···· 这一轮 ····")
    # print(xLi)

    idTem = ''      #临时 aid ，用作 json 键名 ，从 xl1 的地址里截取

    jsTem = {}      #临时 json
    AzpID = ''
    Bchgp = ''
    Cpics = ''
    Dother = ''

    # 1作品 id
    xl1 = xLi.find_next().select('div.info > div.title > a')
    for e1 in xl1:
        if ouji%2 == 1:
            continue
        xl1Tem = e1.get('href')
        xl1Tem = xl1Tem.split('-aid-')[-1]
        xl1Tem = xl1Tem.split('.')[0]
        idTem = xl1Tem      # split n get id
        # print(idTem)
        AzpID = "https://www.wnacg.com" + e1.get('href')
        jsTem['AzpID'] = str(AzpID)
        # print(AzpID)
        # print('\n')

    # 2详细页跳转地址
    xl2 = xLi.find_next().select('div.info > div.title > a')
    for e2 in xl2:
        if ouji%2 == 1:
            continue
        Bchgp = e2.text
        jsTem['Bchgp'] = str(Bchgp)
        # print(Bchgp)
        # print('\n')

    # 3缩略图
    xl3 = xLi.find_next().select('div.pic_box > a > img')
    for e3 in xl3:
        if ouji%2 == 1:
            continue
        Cpics = "https:" + e3.get('src')
        jsTem['Cpics'] = str(Cpics)
        # print(Cpics)
        # print('\n')

    # 4其他基本描述(页数与日期)
    xl4 = xLi.find_next().select('div.info > div.info_col')
    for e4 in xl4:
        if ouji%2 == 1:
            continue
        Dother = e4.text
        jsTem['Dother'] = str(Dother)
        # print(Dother)
        # print('\n')

    # 放入总json中
    TotaljsData[xl1Tem] = jsTem
    xl1Tem = ''

    ouji = ouji + 1


print('\n\n\n\n\n\n')


print(TotaljsData)


print('\n\n\n\n\n\n')


# 3）获取当前页码 ，并记录
nowPageNum = driver.find_element(By.XPATH,'/html/body/div[4]/div[2]/div[2]/div/span[1]')
print("\n当前页码 : " + nowPageNum.text)


# 4）判断是否到达 指定页码
#if(nowPageNum.text == specilNum)
#    print("\n当前已到达指定页码")


# 5）判断指定元素(Next按钮)出现
wait = WebDriverWait(driver, 2000)
button = wait.until(EC.presence_of_element_located((By.XPATH,'/html/body/div[4]/div[2]/div[2]/div/span[2]/a')))


# 6）翻页 【 等待1.5秒（随机1~3秒）】
sleep(3)
button.click()


# 7）等待页面加载完成
driver.implicitly_wait(2000)




sleep(3)
### 先采集 1000页 ，共 2万个 ###############################################################

# 关闭浏览器实例
driver.quit()