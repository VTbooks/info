### 获得链接资源的大小

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random
import requests



# https://v1.wzip.download/down/2518/f5d1683f3e6f5206ec7023bd32168d12.zip?n=251711
# http://www.archive.org/download/MIT6.006F11/MIT6_006F11_lec01_300k.mp4

MitOpenCourseUrl = "https://v1.wzip.download/down/2518/f5d1683f3e6f5206ec7023bd32168d12.zip?n=251711"
resHead = requests.head(MitOpenCourseUrl)
resGet = requests.get(MitOpenCourseUrl,stream=True)

# resHead.headers['Content-length'] # output 169
# resGet.headers['Content-length'] # output 121291539

print(resHead.headers['Content-length'])
print(resGet.headers['Content-length'])