### 实验代码

# 导入需要的库
from time import sleep

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# 导入Keys模块，用于模拟键盘按键操作
from selenium.webdriver.common.keys import Keys

# 创建Chrome浏览器实例
driver = webdriver.Chrome()

# 打开谷歌网页
driver.get('https://www.72on.com')


# 等待页面加载完成
driver.implicitly_wait(2000)

html = driver.page_source
print(html)

# 最大化浏览器窗口
driver.maximize_window()



# 等待页面中的按钮出现
OverseaBtn = driver.find_element(By.XPATH,'/html/body/header/div/nav/ul/li[2]/a')


# 等待页面中的按钮出现并点击
wait = WebDriverWait(driver, 1000)
button = wait.until(EC.presence_of_element_located((By.XPATH,'/html/body/header/div/nav/ul/li[2]/a')))
button.click()



# 执行JavaScript代码，滚动到页面底部
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")


# 创建ActionChains对象
actions = ActionChains(driver)

# 鼠标点击元素
#actions.click(OverseaBtn).perform()


# 等待页面加载完成
driver.implicitly_wait(6000)


# 刷新当前页面
driver.refresh()


# 等待页面加载完成
driver.implicitly_wait(2000)


sleep(10)

# 关闭浏览器实例
driver.quit()



##########################################################



# 1）获得页面源代码
htmlsrc = driver.page_source
# print(htmlsrc)

# 2）解析页面源代码 ，并获取指定数据 ，并保存
soup = BeautifulSoup(htmlsrc, 'lxml')
#soup.prettify()   # 格式化

htmlpart = soup.select('#bodywrap > div.grid > div.gallary_wrap > ul')
#print(htmlpart)


# for item in htmlpart:
#     print('item : \n')
#     print(item)
#     print('item.text : \n')
#     print(item.text)
#     print('find_all : \n')
#     print(item.find_all('li'))
#     print('children : \n')
#     print(item.children)

print('\n\n\n\n\n\n\n\n\n')


jishu = 0
# 遍歷htmlpart下的所有li標籤

for item in htmlpart:
    print("num : ")
    print(jishu)
    print('\n')
    jishu = jishu + 1

    for Li_tag in item.find_all('li'):
        # print(Li_tag.text)  # 打印li標籤的文本信息
        print("···· 这一轮 ····")
        print(Li_tag.findAllNext)
        print('\n\n\n')
        print(Li_tag.findNextSibling)
        print('\n\n\n')
        print(Li_tag.findAllNext)
        print('\n\n\n')
        print(Li_tag.findNext)
        print('\n\n\n')






