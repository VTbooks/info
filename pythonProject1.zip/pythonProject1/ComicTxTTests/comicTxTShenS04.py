### 实验代码

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random



### 浏览器 基础设置 ###############################################################
def cusBaseSettings():
    # 创建options对象
    options = Options()

    # 设置浏览器窗口大小
    options.add_argument("--window-size=1920,1080")

    # 设置页面加载策略
    prefs = {"profile.managed_default_content_settings.images": 2}
    options.add_experimental_option("prefs", prefs)

    # 创建Chrome浏览器实例
    driver = webdriver.Chrome(options=options)

    # 最大化浏览器窗口
    driver.maximize_window()

    return driver



### 打开 指定浏览页面 ###############################################################
def cusChageToSpePage(driver,SpeUrl):

    if(SpeUrl == ''):
        SpeUrl = 'https://www.wnacg.com'

    # 打开comic网页
    driver.get(SpeUrl)

    # 等待页面加载完成
    driver.implicitly_wait(6000)

    # 执行JavaScript代码，滚动到页面底部
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    # 【 等待1.5秒（随机1~3秒）】
    rg = random.randint(2, 5)
    sleep(rg)

    return driver



### 循环打开 指定页面
def ForOpenSpePage(driver,TotalArrData):

    temJishu = 0

    for x in range(len(TotalArrData)):
        temArr = TotalArrData[x]
        # print(temArr[0])
        # print(temArr[1])
        # print('\n\n')

        speUrl = temArr[1]
        driver = cusChageToSpePage(driver,speUrl)       ### 打开 指定浏览页面
        hepGetPageData(driver,speUrl)                   ### 获得 具体页面数据

        # temJishu = temJishu + 1
        # if temJishu > 10:
        #     return

    print('\n\n\n数据已取出完毕\n\n\n')
    return



### 辅助 ，获得页面数据 ###
def hepGetPageData(driver,speUrl):

    if(speUrl == ''):
        speUrl = 'https://www.wnacg.com/photos-index-aid-72.html'

    # 获得 当前作品的id号
    detailId = ''
    xl1Tem = speUrl
    xl1Tem = xl1Tem.split('-aid-')[-1]
    xl1Tem = xl1Tem.split('.')[0]
    detailId = xl1Tem  # split n get id


    # 1）获得页面源代码
    htmlsrc = driver.page_source
    # print(htmlsrc)


    # 创建总json , 记录专栏页面数据
    TotaljsData = {}


    # 2）解析页面源代码 ，获取指定数据
    soup = BeautifulSoup(htmlsrc, 'lxml')
    soup.prettify()  # 格式化

    temJsData = {}  # 临时 Js数据 , json 要用 大括号{}
    # 1 得到 标题
    ABiaoTi = soup.select('#bodywrap > h2')
    for xe1 in ABiaoTi:
        tem = xe1.text
        temJsData['ABiaoTi'] = tem

    # 2 得到 缩略图
    BSuoPic = soup.select('#bodywrap > div > div.asTBcell.uwthumb > img')
    for xe2 in BSuoPic:
        tem = xe2.get('src')
        temJsData['BSuoPic'] = tem

    # 3 得到 大分类
    CFenLei = soup.select('#bodywrap > div > div.asTBcell.uwconn > label:nth-child(1)')
    for xe3 in CFenLei:
        tem = xe3.text
        temJsData['CFenLei'] = tem

    # 4 得到 页数
    DPgNum = soup.select('#bodywrap > div > div.asTBcell.uwconn > label:nth-child(2)')
    for xe4 in DPgNum:
        tem = xe4.text
        temJsData['DPgNum'] = tem

    # 5 得到 分类标签
    ETag = soup.select('#bodywrap > div > div.asTBcell.uwconn > div')
    allA = ''
    temVec = []

    for a5 in ETag:    # 获得所有 子标签(a标签)
        allA = a5

    for e5 in allA:     # 获得所有a标签 里的 内容
        tem = e5.text
        temVec.append(tem)
    temJsData['ETag'] = temVec

    # 6 得到 简介
    FDstr = soup.select('#bodywrap > div > div.asTBcell.uwconn > p')
    for xe6 in FDstr:
        tem = xe6.text
        temJsData['FDstr'] = tem

    print('\n\n')
    print(temJsData)

    ### temjs存入 总Json中
    TotaljsData[detailId] = temJsData

    # 写入本地文件中
    hepWriteTLocal(TotaljsData)

    sleep(3)

    return



### 辅助 ，数据写到本地
def hepWriteTLocal(longJsTxT):
    path = '../Srcs/comicdetail.json'

    # 1 创建个变量接收 文件内的数据
    content = ''

    # 2 打开 文件 读取数据
    with open(path, 'r') as f:
        content = json.load(f)

    # 3 追加 新数据
    content.update(longJsTxT)

    # 4 写入 文件
    with open(path, 'w') as f:
        json.dump(content, f, ensure_ascii=False)       # 保持字符集编码

    return



### 辅助 ，加载Json数据
def hepLoadJson():
    path = '../Srcs/comicsave.json'
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    TotalArrData = [] # 创建数组 存储每个作品的 id和地址
    for key in jsContent:
        temkey = key                    # 获得 作品 id
        temZhi = jsContent[key]
        temZhi = temZhi['AzpID']        # 获得 详细页面 的 地址

        temArr = [temkey, temZhi]
        TotalArrData.append(temArr)    # 将一个需要的键值对放入 总数组

        # print("aid : " , temkey , "\n")
        # print("adr : " , temZhi , "\n")
        # print("temArr : " , temArr , "\n")
        print('\n')

    # print(TotalArrData)

    return TotalArrData



### 从指定页 起点 开始
### 单行本 单个具体漫画页 数据获取 实验代码
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")

    driver = cusBaseSettings()                      ### 浏览器 基础设置

    TotalArrData = hepLoadJson()                    ### 打开Json 获得数据

    ForOpenSpePage(driver,TotalArrData)             ### 循环打开 指定页面

