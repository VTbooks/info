### 此页代码 用于 获得缩略图

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random
import urllib.request
from urllib.request import urlretrieve
import shutil,os
import requests
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import appdirs



### 浏览器 基础设置 ###############################################################
def cusBaseSettings():
    # 创建options对象
    options = Options()

    # 设置浏览器窗口大小
    options.add_argument("--window-size=1920,1080")

    prefs = {"download.default_directory": "C:\\Users\\Tbs\\Downloads"}        # 虚机 位置
    options.add_experimental_option("prefs", prefs)


    # 创建Chrome浏览器实例
    driver = webdriver.Chrome(options=options)

    # 最大化浏览器窗口
    driver.maximize_window()

    # 获取缓存路径
    cache_path = appdirs.user_cache_dir()
    print(cache_path)

    return driver



### 循环打开 指定页面 ###############################################################
def ForOpenSpePage(driver,TotalArrData):

    for x in range(len(TotalArrData)):
        temArr = TotalArrData[x]
        # print(temArr[0])        # id
        # print(temArr[1])        # pic 地址
        # print('\n\n')

        spepid = temArr[0]
        speUrl = temArr[1]

        cusChageToSpePage(driver,speUrl)                ### 打开 指定页面
        getFilebyurl(driver)                            ### 下载 指定文件
        # moveNchageFiletoPlace(spepid)                   ### 更改 文件名称 | 移动 文件位置


    print('\n\n\n数据已取出完毕\n\n\n')
    return



### 打开 指定页面 ###############################################################
def cusChageToSpePage(driver,SpeUrl):

    if(SpeUrl == ''):
        SpeUrl = 'https://www.wnacg.com'

    # 打开comic网页
    driver.get(SpeUrl)

    # 等待页面加载完成
    driver.implicitly_wait(4000)

    return driver



### 下载 图片
def getFilebyurl(driver):
    return



### 更改文件名称 并 移动文件 到指定 位置
def moveNchageFiletoPlace(spepid):

    path = r"C:\\Users\\Tbs\\Downloads"
    filenameArr = os.listdir(path)
    print(os.listdir(path))

    if(len(filenameArr) == 0):
        return

    fhzhui = filenameArr[0]                     # 取 数组第一个数据
    fhzhui = fhzhui.split('.')[-1]              # 文件后缀

    movApath = "C:\\Users\\Tbs\\Downloads\\" + str(filenameArr[0])
    movBpath = "C:\\Users\\Tbs\\PycharmProjects\\pyth_ShenS\\Srcs\\LiuLanPisc\\" + str(spepid) + '.' + str(fhzhui)

    print(movApath)
    print(movBpath)

    shutil.move(movApath,movBpath)

    return



### 辅助 ，加载Json数据 ，Get Pic Link ###
def hepLoadJson():
    path = '../Srcs/comicsave.json'     #虚拟机 使用
    # path = 'D:\\SLabs\\pyApps\\com5Downpic\\srcs\\comicsave.json'     #真机 使用
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    jishu = 0
    TotalArrData = [] # 创建数组 存储每个作品的 id和下载页地址
    for key in jsContent:
        if(jishu >= 3):
            continue
        temkey = key                    # 获得 作品 id
        temZhi = jsContent[key]         # 获得 id对应的一条数据
        temZhi = temZhi['Cpics']        # 获得 数据 中的 pic地址

        temArr = [temkey, temZhi]
        TotalArrData.append(temArr)    # 将一个地址放入 总数组
        jishu += 1

    return TotalArrData



### 下载 图片
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")

    TotalPicsArr = hepLoadJson()                    ### 辅助 ，加载Json数据

    driver = cusBaseSettings()                      ### 浏览器 基础设置

    ForOpenSpePage(driver,TotalPicsArr)             ### 循环打开 指定页面

    sleep(12)

