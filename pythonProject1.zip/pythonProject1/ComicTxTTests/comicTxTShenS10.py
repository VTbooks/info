### 测试 检测 文件夹内的zip文件 是否 与 Json数据 匹配 ，用于 查漏补下

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import random
import os

import json



### 辅助 ，加载Json数据 ，Get Pic Link ###
def hepLoadJson():
    path = '../Srcs/ZLDanXing/temdownlink.json'     #虚拟机 使用
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    jishu = 0
    TotalArrData = {} # 创建数组 存储每个作品的 id和下载页地址
    for key in jsContent:
        if(jishu >= 200):
            continue
        temkey = key                    # 获得 作品 id
        temZhi = jsContent[key]         # 获得 id对应的一条数据
        temZhi = temZhi['GDlowlink']        # 获得 数据 中的 文档地址

        jishu += 1
        # print(temkey)
        TotalArrData[temkey] = temZhi   # 生成新

    print(TotalArrData)

    return TotalArrData


### 辅助 ，便利文件夹
def hepBianLi():
    paths = os.walk(r'C:\Users\Tbs\Downloads')

    TotalZipName = {}

    for path, dir_lst, file_lst in paths:
        for file_name in file_lst:
            # print(os.path.join(path, file_name))
            # print(file_name)
            tem = file_name.split('.')[0]
            TotalZipName[tem] = file_name

    print(TotalZipName)

    return TotalZipName


### 辅助 ，对比
def hepDuiBi(TotalPicsArr,TotalZipName):

    for ex in TotalZipName:
        # print(ex)
        TotalPicsArr[ex] = TotalZipName[ex]     # 覆盖已下载的数据 ，未下载的 留着 链接 ，再点击 重新下载

    print(TotalPicsArr)
    # for e in TotalPicsArr:
    #     print(TotalPicsArr[e])

    print('\n\n\n')

    temArr = {}
    for ee in TotalPicsArr:
        temK = str(ee) + '.zip'
        temJ = str(TotalPicsArr[ee])

        # print(temK)
        # print(temJ)
        if(temK != temJ):
            temArr[temK] = temJ                 # 把遗漏的链接 筛选出来
            continue

    for sx in temArr:
        print(temArr[sx])

    # print(temArr)

    return


### 下载 图片
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")

    TotalPicsArr = hepLoadJson()                    ### 辅助 ，加载Json数据

    TotalZipName = hepBianLi()

    hepDuiBi(TotalPicsArr,TotalZipName)


