from selenium import webdriver
import shutil
import os
# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random
import urllib.request
from urllib.request import urlretrieve
import shutil
import tempfile


# 打开Chrome浏览器
browser = webdriver.Chrome()

# 访问需要提取媒体文件的页面
browser.get("https://example.com")

# 获取缓存路径
# cache_path = browser.execute_script("return window.chrome.loadTimes().firstPaintTime * 1000;")

cache_path = tempfile.gettempdir()
print(cache_path)


# 获取所有缓存文件
cache_files = os.listdir(cache_path)

# 创建保存媒体文件的文件夹
if not os.path.exists("media"):
    os.makedirs("media")

# 遍历所有缓存文件
for file in cache_files:
    # 查找媒体文件
    if "video" in file or "audio" in file or "image" in file:
        # 复制媒体文件到指定路径
        shutil.copy2(os.path.join(cache_path, file), os.path.join("media", file))
#
# sleep(10)
#
# # 关闭浏览器
# browser.quit()