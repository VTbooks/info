### 此页代码 用于 获得 浏览页 缩略图

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import json
import random
import urllib.request
from urllib.request import urlretrieve
import shutil,os
import requests
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import appdirs



### 浏览器 基础设置 ###############################################################
def cusBaseSettings():
    # 创建options对象
    options = Options()
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    options.add_argument('--start-maximized')

    # 设置浏览器窗口大小
    options.add_argument("--window-size=300,400")

    # 创建Chrome浏览器实例
    driver = webdriver.Chrome(options=options)

    # # 最大化浏览器窗口
    # driver.maximize_window()

    return driver



### 循环打开 指定页面 ###############################################################
def ForOpenSpePage(driver,TotalArrData):

    for x in range(len(TotalArrData)):
        temArr = TotalArrData[x]
        # print(temArr[0])        # id
        # print(temArr[1])        # pic 地址
        # print('\n\n')

        spepid = temArr[0]
        speUrl = temArr[1]

        cusChageToSpePage(driver,speUrl,spepid)                ### 打开 指定页面 ，下载 指定文件

    print('\n\n\n数据已取出完毕\n\n\n')
    return



### 打开 指定页面 ###############################################################
def cusChageToSpePage(driver,speUrl,spepid):

    if(speUrl == ''):
        speUrl = 'https://www.wnacg.com'

    temUrl = speUrl.split('.')[-1]
    temUrl = str(temUrl)

    if(temUrl != 'jpg' and temUrl != 'png' and temUrl != 'jpeg' and temUrl != 'webp'):
        print('invalid url : ' + spepid)
        print('invalid url : ' + temUrl)
        print('\n')
        return driver

    # 打开comic网页
    driver.get(speUrl)

    # 等待页面加载完成
    driver.implicitly_wait(3000)

    sleep(0.6)
    driver.save_screenshot("C:\\Users\\Tbs\\PycharmProjects\\pyth_ShenS\\Srcs\\ZLHanMan\\LiuLanPisc\\" + str(spepid) + '.png')
    sleep(0.4)

    print("spepid ：" + spepid)

    return driver



### 辅助 ，加载Json数据 ，Get Pic Link ###
def hepLoadJson():
    path = '../../Srcs/ZLHanMan/HMcomicsave.json'     #虚拟机 使用
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    # jishu = 0
    TotalArrData = [] # 创建数组 存储每个作品的 id和下载页地址
    for key in jsContent:
        # if(jishu >= 3):
        #     continue
        temkey = key                    # 获得 作品 id
        temZhi = jsContent[key]         # 获得 id对应的一条数据
        if(temkey == '' or temZhi == ''):
            print('have null value')
            continue

        temZhi = temZhi['Cpics']        # 获得 数据 中的 pic地址

        temArr = [temkey, temZhi]
        TotalArrData.append(temArr)    # 将一个地址放入 总数组
        # jishu += 1

    # print(TotalArrData)

    return TotalArrData



### 下载 图片
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")

    TotalPicsArr = hepLoadJson()                    ### 辅助 ，加载Json数据

    driver = cusBaseSettings()                      ### 浏览器 基础设置

    ForOpenSpePage(driver,TotalPicsArr)             ### 循环打开 指定页面

    sleep(12)

