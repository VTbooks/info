### 此页代码 用于 多线程 下载 辅助

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import random

import os
import json
import shutil




### 浏览器 基础设置 ###############################################################
def cusBaseSettings():
    # 创建options对象
    options = Options()

    # 设置浏览器窗口大小
    options.add_argument("--window-size=1280,960")

    # 设置页面加载策略
    # prefs = {"profile.managed_default_content_settings.images": 2}
    # options.add_experimental_option("prefs", prefs)

    # 创建Chrome浏览器实例
    driver = webdriver.Chrome(options=options)

    # # 最大化浏览器窗口
    # driver.maximize_window()

    return driver



### 循环打开 指定页面 ###############################################################
def ForOpenSpePage(driver,TotalArrData):

    jishu = 0
    for x in range(len(TotalArrData)):
        temArr = TotalArrData[x]
        print(temArr[0])        # id
        print(temArr[1])        # pic 地址

        spepid = temArr[0]
        speUrl = temArr[1]

        jishu += 1
        cusChageToSpePage(driver,speUrl,spepid)                ### 打开 指定页面 ，下载 指定文件

        whileCheckDownStat(spepid)                             ### 循环检测 指定文件 是否 下载完成

        print('yixiazai : ' , jishu)

        # 【 等待1.5秒（随机1~2秒）】
        rg = random.randint(3, 8)
        sleep(rg)

        print('\n\n')

    print('\n\n\n数据已取出完毕\n\n\n')
    return



### 打开 指定页面 ###############################################################
def cusChageToSpePage(driver,speUrl,spepid):

    if(speUrl == ''):
        speUrl = 'https://v1.wzip.download/down/2398/1b206cd29d2ff51d779097b681732c4c.zip?n=239787'

    print("spepid ：" + spepid)

    # 打开comic网页
    driver.get(speUrl)

    # 等待页面加载完成
    driver.implicitly_wait(3000)

    sleep(1)

    return driver



### 循环检测 下载情况
def whileCheckDownStat(spepid):
    canNext = 1         # 下载完成 0 ，还在下载中 1
    checknum = 0                    # 检查文件夹的次数 ，超过一定次数 ，直接跳过 ，开始下载下一个

    while(canNext):
        sleep(2)
        canNext = hepCheckFileNMoveFile(spepid)              # 检测指定文件是否下载完成
        checknum += 1
        print('检查次数 ：', checknum)
        if(checknum >= 30):
            checknum = 0
            canNext = 0

    print('check is over , can next')

    return



### 辅助 ，检测指定文件夹下的文件是否下载完成 。移动文件至指定文件夹
def hepCheckFileNMoveFile(spepid):
    ndfile = str(spepid) + '.zip'
    ifnd = 1                        # 发现 0 ，未发现 1

    paths = os.walk(r'C:\\Users\\11\\Downloads')
    TotalZipName = {}

    for path, dir_lst, file_lst in paths:
        for file_name in file_lst:
            if(ndfile == file_name):
                # 把文件移走
                ifnd = 0                                    # 文件夹内 发现 指定文件
                print('发现指定文件')
                return ifnd


    print("文件夹内文件数 : ", len(TotalZipName))
    # print(TotalZipName)

    print('未发现文件 ，准备下一次文件夹检测')

    return ifnd



### 辅助 ，加载Json数据 ，Get Pic Link ###
def hepLoadJson():
    path = 'C:\\Users\\11\\PycharmProjects\\pythonProject1\\Srcs\\ZLAhome\\Temtotaldownlink.json'     #虚拟机 使用
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    jishu = 0
    TotalArrData = [] # 创建数组 存储每个作品的 id和下载页地址
    for key in jsContent:
        if(jishu >= 2301):              # 下载 2200个（20240601）
            continue
        temkey = key                    # 获得 作品 id
        temZhi = jsContent[key]         # 获得 id对应的一条数据
        temZhi = temZhi['GDlowlink']        # 获得 数据 中的 文档地址

        temArr = [temkey, temZhi]
        TotalArrData.append(temArr)    # 将一个地址放入 总数组
        jishu += 1
        # print(temArr)

    print(' TotalArrData : ',len(TotalArrData))

    return TotalArrData



### 下载 图片
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")

    TotalPicsArr = hepLoadJson()                    ### 辅助 ，加载Json数据

    driver = cusBaseSettings()                      ### 浏览器 基础设置

    ForOpenSpePage(driver,TotalPicsArr)             ### 循环打开 指定页面

    sleep(6)

