### 多线程 下载          ### 还需多IP ，暂时 不使用此页代码

# 导入需要的库
from time import sleep
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

# 导入WebDriverWait类和expected_conditions模块
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC    # 等待条件

from bs4 import BeautifulSoup           # 解析html的
import random

import os
import json
import shutil
import numpy as np


import comicA9DownFile
import threading
import time


exitFlag = 0                                                ### 设置的一个变量 ，用于终止线程

### 线程类
class myThread (threading.Thread):
    def __init__(self, threadID, name, tArr):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.temArr = tArr
    def run(self):
        print ("开始线程：" + self.name)
        creatThreadson(self.name, self.temArr)
        print ("退出线程：" + self.name)


### 函数 ，创建线程内容
def creatThreadson(threadName,tArr):
    if exitFlag:
        threadName.exit()

    driver = comicA9DownFile.cusBaseSettings()                      ### 浏览器 基础设置

    comicA9DownFile.ForOpenSpePage(driver,TotalPicsArr)             ### 循环打开 指定页面



### 辅助 ，加载Json数据 ，Get Pic Link ###
def hepLoadJson():
    path = 'C:\\Users\\11\\PycharmProjects\\pythonProject1\\Srcs\\ZLAhome\\Temtotaldownlink.json'     #虚拟机 使用
    with open(path) as user_file:
        jsonObj = user_file.read()

    jsContent = json.loads(jsonObj) # 使用 load() 方法，Json字符串 转成 Py字典对象 。从此字典中，你可以访问其中的键和值。

    jishu = 0
    TotalArrData = [] # 创建数组 存储每个作品的 id和下载页地址
    for key in jsContent:
        if(jishu >= 12):              # 下载 2200个（20240601）
            continue
        temkey = key                    # 获得 作品 id
        temZhi = jsContent[key]         # 获得 id对应的一条数据
        temZhi = temZhi['GDlowlink']        # 获得 数据 中的 文档地址

        temArr = [temkey, temZhi]
        TotalArrData.append(temArr)    # 将一个地址放入 总数组
        jishu += 1
        # print(temArr)

    print(' TotalArrData : ',len(TotalArrData))

    return TotalArrData



### 下载 图片
if __name__ == "__main__":
    print("—————————— 开始执行 ——————————")

    TotalPicsArr = hepLoadJson()                    ### 辅助 ，加载Json数据

    newarr = np.array_split(TotalPicsArr, 4)            ### 拆分数组 ，拆分成4份


    threadArr = []

    for si in range(newarr.__len__()):
        print("创建线程 : " , si)
        print("分配数据 : " , newarr[si])

        # 创建新线程
        thread = myThread(si, str(si), newarr[si])
        threadArr.append(thread)

        # 开启新线程
        thread.start()



    for ele in threadArr:
        # 等待线程终止。默认情况下，join()会一直阻塞，直到被调用线程终止。如果指定了timeout参数，则最多等待timeout秒。
        ele.join()


    print ("退出主线程")

